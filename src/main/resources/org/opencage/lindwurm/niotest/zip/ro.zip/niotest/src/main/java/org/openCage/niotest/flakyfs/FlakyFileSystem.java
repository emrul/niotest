package org.openCage.niotest.flakyfs;

import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileStore;
import java.nio.file.FileSystem;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.WatchService;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.nio.file.spi.FileSystemProvider;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.openCage.kleinod.emergent.Todo.todo;

/**
 * ** BEGIN LICENSE BLOCK *****
 * BSD License (2 clause)
 * Copyright (c) 2006 - 2013, Stephan Pfab
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Stephan Pfab BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * **** END LICENSE BLOCK ****
 */
public class FlakyFileSystem extends FileSystem {
    private Map<RootedPath, List<RootedPath>> dirs = new HashMap<>();
    private Map<RootedPath,byte[]> files = new HashMap<>();

    public FlakyFileSystem() {
        dirs.put( (RootedPath) getPath( getSeparator() ).toAbsolutePath(), new ArrayList<RootedPath>() );
    }

    @Override
    public FileSystemProvider provider() {
        return new FlakyFileSystemProvider();
    }

    @Override
    public void close() throws IOException {
        todo();   //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isOpen() {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isReadOnly() {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getSeparator() {
        return "/";
    }

    @Override
    public Iterable<Path> getRootDirectories() {
        return Collections.singleton( (Path)new RootedPath( this, getSeparator(), getSeparator()));
    }

    @Override
    public Iterable<FileStore> getFileStores() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Set<String> supportedFileAttributeViews() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Path getPath( String first, String... more ) {
        return new RootedPath( this, first, more );
    }

    @Override
    public PathMatcher getPathMatcher( String syntaxAndPattern ) {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public UserPrincipalLookupService getUserPrincipalLookupService() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public WatchService newWatchService() throws IOException {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isDirectory( RootedPath path ) {
        return dirs.containsKey( path.toAbsolutePath() );
    }

    public List<Path> getDirEntries( RootedPath path ) {
        return (List)dirs.get( path.toAbsolutePath() );
    }

    public boolean isFile( RootedPath mpath ) {
        return files.containsKey( mpath );
    }

    public void createDirectroy( RootedPath mpath ) throws NoSuchFileException, FileAlreadyExistsException {
        if ( !isDirectory( (RootedPath) mpath.getParent() )) {
            throw new NoSuchFileException( mpath.getParent().toString() );
        }

        if ( dirs.containsKey( mpath )) {
            throw new FileAlreadyExistsException( mpath.toString() );
        }

        dirs.get( mpath.getParent() ).add( mpath );
        dirs.put( mpath, new ArrayList<RootedPath>() );
    }

    public void setFileContent( RootedPath path, byte[] content ) {
        files.put( path, content );
    }

    public byte[] getFileContent( RootedPath path ) {
        return files.get( path );
    }

    public void delete( RootedPath path ) throws DirectoryNotEmptyException {

        if ( !path.isAbsolute()) {
            throw new IllegalArgumentException( "not abs" );
        }

        if ( files.containsKey(  path )) {
            files.remove( path );
            return;
        }

        if ( !dirs.containsKey( path )) {
            return;
        }

        if ( !dirs.get( path ).isEmpty()) {
            // todo throw correct
            throw new DirectoryNotEmptyException( path.toString() );
        }

        if ( path.equals( path.getRoot() )) {
            throw new IllegalArgumentException( "can't delete root" );
        }

        dirs.get( path.getParent() ).remove( path );
        dirs.remove( path );
    }
}
