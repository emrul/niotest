package org.openCage.niotest.flakyfs;



import java.nio.file.LinkOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;

import static org.openCage.kleinod.emergent.Todo.todo;

/**
 * ** BEGIN LICENSE BLOCK *****
 * BSD License (2 clause)
 * Copyright (c) 2006 - 2013, Stephan Pfab
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Stephan Pfab BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * **** END LICENSE BLOCK ****
 */
public class FlakyFileAttributes implements BasicFileAttributes {
    private final RootedPath path;

    public FlakyFileAttributes( RootedPath path, LinkOption... options ) {
        this.path = path;
    }

    @Override
    public FileTime lastModifiedTime() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public FileTime lastAccessTime() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public FileTime creationTime() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isRegularFile() {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isDirectory() {
        return ((FlakyFileSystem)path.getFileSystem()).isDirectory( path );
    }

    @Override
    public boolean isSymbolicLink() {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isOther() {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public long size() {
        return ((FlakyFileSystem)path.getFileSystem()).getFileContent( path ).length;
    }

    @Override
    public Object fileKey() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
