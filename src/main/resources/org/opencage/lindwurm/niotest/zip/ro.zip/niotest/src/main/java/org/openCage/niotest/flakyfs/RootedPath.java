package org.openCage.niotest.flakyfs;

import org.openCage.kleinod.paths.GetPathConverter;
import org.openCage.kleinod.paths.Relativize;
import org.openCage.kleinod.text.Strings;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import static org.openCage.kleinod.emergent.Todo.todo;

/**
 * ** BEGIN LICENSE BLOCK *****
 * BSD License (2 clause)
 * Copyright (c) 2006 - 2013, Stephan Pfab
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Stephan Pfab BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * **** END LICENSE BLOCK ****
 */
public class RootedPath implements Path {
    private final FileSystem fileSystem;
    private final List<String> elems;
    private final boolean absolute;

    public RootedPath( FileSystem memoryFileSystem, String first, String... more ) {
        GetPathConverter gp = new GetPathConverter( memoryFileSystem.getSeparator(), first, more );
        elems = gp.getAll();
        fileSystem = memoryFileSystem;
        absolute = gp.isAbsolute();

        if ( elems.size() > 1 && elems.contains( "" )) {
            throw new IllegalStateException( "empty path segment" );
        }

        if ( elems.isEmpty() && !absolute) {
            todo();
        }
    }

    protected RootedPath( FileSystem fileSystem, boolean absolute, List<String> elems ) {
        this.fileSystem = fileSystem;
        this.elems = elems;
        this.absolute = absolute;
        if ( elems.size() > 1 && elems.contains( "" )) {
            throw new IllegalStateException( "empty path segment" );
        }

        if ( elems.isEmpty() && !absolute) {
            todo();
        }
    }

    @Override
    public FileSystem getFileSystem() {
        return fileSystem;
    }

    @Override
    public boolean isAbsolute() {
        return absolute;
    }

    @Override
    public Path getRoot() {
        if ( isAbsolute() ) {
            return new RootedPath( fileSystem, fileSystem.getSeparator() );
        }

        return null;
    }

    @Override
    public Path getFileName() {

        if ( elems.isEmpty() && absolute ) {
            return null;
        }

        if ( elems.size() <= 1 ) {
            if ( absolute ) {
                return new RootedPath( fileSystem, false, elems );
            }
            return this;
        }

        return new RootedPath( fileSystem, elems.get( elems.size() - 1 ) );
    }

    @Override
    public Path getParent() {
        if ( equals( getRoot())) {
            return null;
        }

        if ( !absolute ) {
            return null;
        }

        return new RootedPath( fileSystem, absolute, elems.subList( 0, elems.size() - 1 ) );
    }

    @Override
    public int getNameCount() {
        return elems.size();
    }

    @Override
    public Path getName( int index ) {
        if ( index < 0 || index > elems.size() ) {
            throw new IllegalArgumentException( "index " + index + " <0 or larger than " + getNameCount() );
        }
        return new RootedPath( fileSystem, elems.get( index ) );
    }

    @Override
    public Path subpath( int beginIndex, int endIndex ) {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean startsWith( Path other ) {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean startsWith( String other ) {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean endsWith( Path other ) {
        for ( int i = 0; i < other.getNameCount(); i++ ) {
            if ( i >= getNameCount() ) {
                return false;
            }

            if ( !getName( getNameCount() - 1 - i ).equals( other.getName( other.getNameCount() - 1 - i ) )) {
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean endsWith( String other ) {
        todo();
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Path normalize() {
        List<String> newEls = new ArrayList<>();

        for ( int i = 0; i < elems.size(); i++ ) {
            switch( elems.get( i )) {
                case ".." :
                    if ( newEls.size() >0 && !newEls.get( newEls.size()-1 ).equals( ".." )) {
                        newEls.remove( newEls.size()-1 );
                    }
                    break;
                case "." :
                    // nix
                    break;
                case "" :
                    // nix
                    break;
                default:
                    newEls.add( elems.get( i ) );
            }

        }

        if ( !absolute && newEls.isEmpty() ) {
            return new RootedPath( fileSystem, absolute, Collections.singletonList("") );
        }

        return new RootedPath( fileSystem, absolute, newEls );
    }

    @Override
    public Path resolve( Path other ) {
        if ( other.isAbsolute() ) {
            return other;
        }

        RootedPath rother = (RootedPath) other;

        if ( rother.elems.size() == 1 && rother.elems.get( 0 ).isEmpty() ) {
            return this;
        }

        if ( elems.size() == 1 && elems.get( 0 ).isEmpty() ) {
            return other;
        }

        List<String> newEls = new ArrayList<>();
        newEls.addAll( elems );
        newEls.addAll( ((RootedPath)other).elems );

        Path ret =  new RootedPath( fileSystem, absolute, newEls );

        if ( ret.toString().contains( "//" )) {
            todo();
        }

        return ret;
    }

    @Override
    public Path resolve( String other ) {
        return resolve( new RootedPath( fileSystem, other ) );
    }

    @Override
    public Path resolveSibling( Path other ) {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Path resolveSibling( String other ) {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Path relativize( Path other ) {
        if ( isAbsolute() != other.isAbsolute()) {
            throw new IllegalArgumentException( "'other' is different type of Path" );
        }

        return new RootedPath( fileSystem, false, Relativize.relativize( elems, ( (RootedPath) other ).elems ));
    }

    @Override
    public URI toUri() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Path toAbsolutePath() {
        if ( absolute ) {
            return this;
        }

        return new RootedPath( fileSystem, fileSystem.getSeparator(), elems.toArray( new String[]{} ) );
    }

    @Override
    public Path toRealPath( LinkOption... options ) throws IOException {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public File toFile() {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public WatchKey register( WatchService watcher, WatchEvent.Kind<?>[] events, WatchEvent.Modifier... modifiers ) throws IOException {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public WatchKey register( WatchService watcher, WatchEvent.Kind<?>... events ) throws IOException {
        todo();
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Iterator<Path> iterator() {
        return new Iterator<Path>() {
            int idx = 0;

            @Override
            public boolean hasNext() {
                return idx < elems.size();
            }

            @Override
            public Path next() {
                Path ret = new RootedPath( fileSystem, elems.get( idx ) );
                idx++;
                return ret;
            }

            @Override
            public void remove() {
                todo();
            }
        };
    }

    @Override
    public int compareTo( Path other ) {
        todo();
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }


    @Override
    public String toString() {
        return Strings.join( elems ).
                separator( fileSystem.getSeparator() ).
                prefix( isAbsolute() ? fileSystem.getSeparator() : "" ).
                allwaysPreAndPost().
                toString();
    }

    @Override
    public boolean equals( Object o ) {
        if( this == o ) return true;
        if( o == null || getClass() != o.getClass() ) return false;

        RootedPath paths = (RootedPath) o;

        if( elems != null ? !elems.equals( paths.elems ) : paths.elems != null ) return false;
        if( fileSystem != null ? !fileSystem.equals( paths.fileSystem ) : paths.fileSystem != null ) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = fileSystem != null ? fileSystem.hashCode() : 0;
        result = 31 * result + ( elems != null ? elems.hashCode() : 0 );
        return result;
    }
}
