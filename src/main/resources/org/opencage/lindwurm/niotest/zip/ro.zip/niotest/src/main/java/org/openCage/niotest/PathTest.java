package org.openCage.niotest;

import org.hamcrest.CoreMatchers;
import org.hamcrest.core.IsNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.openCage.kleinod.collection.Forall;
import org.openCage.kleinod.paths.CapabilitiesProvider;
import org.openCage.kleinod.paths.PathUtils;
import org.openCage.kleinod.type.ImmuDate;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SeekableByteChannel;
import java.nio.charset.Charset;
import java.nio.file.ClosedFileSystemException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystemAlreadyExistsException;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.ProviderMismatchException;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static java.nio.file.StandardOpenOption.READ;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assume.assumeTrue;
import static org.openCage.kleinod.emergent.Todo.todo;
import static org.openCage.niotest.PathAbsolute.absolute;
import static org.openCage.niotest.PathAbsolute.relative;
import static org.openCage.niotest.PathExists.exists;
import static org.openCage.niotest.PathIsDirectory.isDirectory;
import static org.openCage.niotest.PathIsDirectory.isNotDirectory;

/**
 * ** BEGIN LICENSE BLOCK *****
 * BSD License (2 clause)
 * Copyright (c) 2006 - 2013, Stephan Pfab
 * All rights reserved.
 * <p/>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * <p/>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Stephan Pfab BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * **** END LICENSE BLOCK ****
 */
public class PathTest {

    private CapabilitiesProvider capabilitiesProvider = new CapabilitiesProvider();

    public static class TmpDir implements TmpResource<Path> {

        private final int kidCount;

        public TmpDir( int kidCount ) {
            this.kidCount = kidCount;
        }

        Path tmp;


        @Override
        public Path get( String prefix ) {
            tmp = PathUtils.getTmpDir( "PathTest-" + prefix);
            try {
                Files.createDirectories( tmp );
                for ( int i = 0; i < kidCount; i++ ) {
                    Files.createDirectory( tmp.resolve( "kid-" + i ) );
                }
            } catch( IOException e ) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                todo();
            }
            return tmp;
        }

        @Override
        public void cleanup() {
            if ( tmp != null ) {
                PathUtils.delete( tmp );
                tmp = null;
            }
        }
    }

    protected TestParams p;

    public PathTest() {

        p = new TestParams().readOnlyFileSystem( FileSystems.getDefault() );

        p.legalPathElement( "abc", "duh", "bar", "foo");
        p.nonExistingPath( FileSystems.getDefault().getPath( "sdfgwqrefqvrqerfaerf" ).toAbsolutePath());
        p.tmpDir( new TmpDir(0));

        p.nonEmptyDir( new TmpDir( 1 ), 1 );
        p.setEnvForNewFS( Collections.EMPTY_MAP );

    }

    @Before
    public void beforeEachMethods() {
        afterEachMethod();
    }

    @After
    public void afterEachMethod() {
        if ( p.tmpDir != null ) {
            p.tmpDir.cleanup();
        }

        if ( p.nonEmptyDir != null ) {
            p.nonEmptyDir.cleanup();
        }
    }


    @Test
    public void testAADefault() {
        Path path = p.readOnlyFileSystem.getPath( "" );
        assertThat( path.isAbsolute(), is(false));

        assertThat( path, notNullValue() );
        assertThat( path.getNameCount(), is(1));

        assertThat( path.getRoot(), nullValue());

        assertThat( path.toString(), is( "" ));

        assertThat( path, isDirectory() );
    }

    @Test
    public void testRootOfRelative() {

        assertThat( p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).getRoot(), IsNull.nullValue() );
    }

    @Test
    public void testRootOfAbsolute() {
        Path root =  p.readOnlyFileSystem.getPath("").toAbsolutePath().getRoot();
        assertTrue( root.isAbsolute());
        assertEquals(root.getRoot(), root);
        assertThat( root.getNameCount(), is(0));

        boolean found = false;

        for ( Path aroot : p.readOnlyFileSystem.getRootDirectories() ) {
            assertThat( aroot.getNameCount(), is(0));

            found |= aroot.equals( root );
        }

        assertTrue( "root of default path is not one of the roots", found );
    }


    @Test
    public void testRootAttis() throws IOException {
        Path root =  p.readOnlyFileSystem.getPath("").toAbsolutePath().getRoot();

        assertThat( root, isDirectory() );

        // no throw
        Files.readAttributes( root, BasicFileAttributes.class );
    }

    @Test
    public void testGetFileSystem() {
        assertEquals( p.readOnlyFileSystem, p.readOnlyFileSystem.getPath( "" ).getFileSystem() );
    }

    @Test
    public void testContentOfDefault() throws IOException {

        // existing path
        Path path = p.readOnlyFileSystem.getPath("");

        assertThat( path, relative() );
        assertThat( path, isDirectory() );

        try ( DirectoryStream<Path> stream = Files.newDirectoryStream( path )) {}
    }

    @Test
    public void testContentOfNonEmptyDir() throws IOException {

        // existing path
        Path path = p.getNonEmptyDir("contentOfNonEmpty");

        assertThat( path, isDirectory() );


        try ( DirectoryStream<Path> stream = Files.newDirectoryStream( path )) {
            int count = 0;
            for ( Path kid : stream ) {
//                System.out.println(kid);
                count++;
            }
            assertEquals( p.getCountOfNonEmptyDir(), count );
        }
    }

    @Test
    public void testContentOfNonEmptyDirFiltered() throws IOException {

        // existing path
        Path path = p.getNonEmptyDir("contentOfNonEmptyFiltered");

        assertThat( path, isDirectory() );

        // filter first
        DirectoryStream.Filter<Path> filter = new DirectoryStream.Filter<Path>() {

            boolean first = true;

            @Override
            public boolean accept( Path entry ) throws IOException {
                if ( first ) {
                    first = false;
                    return false;
                }
                return true;
            }
        };

        int count = 0;
        for ( Path kid : Files.newDirectoryStream( path, filter )) {
//            System.out.println(kid);;
            count++;
        }

        assertEquals( p.getCountOfNonEmptyDir() - 1, count );
    }

    @Test
    public void testToAbsolute() {
        Path path = p.readOnlyFileSystem.getPath("");

        assertThat( path.toAbsolutePath(), absolute());
        assertEquals( path.toAbsolutePath(), path.toAbsolutePath().toAbsolutePath());
    }

    @Test
    public void testToString() {
        Path path = p.readOnlyFileSystem.getPath( "" );

        assertFalse( path.toString().startsWith( p.readOnlyFileSystem.getSeparator() ) );
        // TODO windows ?
        assertTrue( "toString of absolute path does not start with separator", path.toAbsolutePath().toString().startsWith( p.readOnlyFileSystem.getSeparator() ) );

        assertThat( p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).toString().contains( p.getLegalPathElement() ), CoreMatchers.is( true ) );
    }
//
////    @Test
////    public void testCompare() {
////        Path path1 = fileSystem.getPath("/", "a", "b");
////        Path path2 = fileSystem.getPath("/", "c");
////
////        System.out.println(path1.compareTo(path2));
////
////    }
//
//
////    @Test
////    public void testStartsWith() {
////        Path path1 = fileSystem.getPath("/", "a", "b");
////        Path path2 = fileSystem.getPath("/", "c");
////
////        System.out.println(path1.startsWith(path2));
////
////    }
//
//
//    @Test
//    public void testDirStreamAbsolutePath() throws IOException {
//        Path abso = p.fileSystem.getPath("").toAbsolutePath();
//
//        for ( Path kid : Files.newDirectoryStream(abso)) {
//            System.out.println(kid);
//            assertThat( kid.isAbsolute(), CoreMatchers.is(true));
//        }
//
//    }
//
//    @Test
//    public void testDirStreamRelativePath() throws IOException {
//        Path rel = p.fileSystem.getPath("");
//
//        for ( Path kid : Files.newDirectoryStream(rel)) {
//            System.out.println(kid);
//            assertThat( kid.isAbsolute(), CoreMatchers.is(false));
//        }
//    }
//
    @Test
    public void testIsDirectoryExists() throws IOException {
        Path rel = p.readOnlyFileSystem.getPath("");

        assertThat( rel, isDirectory() );

        Path abs = p.readOnlyFileSystem.getPath("").toAbsolutePath();

        assertThat( abs, isDirectory() );
    }

    @Test
    public void testIsDirectoryNotExists() throws IOException {

        assertThat( p.getNonExistingPath().getRoot().relativize( p.getNonExistingPath() ), isNotDirectory() );

        assertThat( p.getNonExistingPath().toAbsolutePath(), isNotDirectory() );
    }
//
////    @Test
////    public void testResolveSibling() {
////        Path some = FileSystems.getDefault().getPath("").toAbsolutePath();
////        System.out.println(some);
////        System.out.println(some.resolveSibling(""));
////    }
//
//    @Test
//    public void testNewByteChannel() throws IOException {
//        Path target = p.getTmpDir().resolve( p.getLegalPathElement() ).toAbsolutePath();
//
//        Files.createDirectories( target.getParent() );
//
//        try ( SeekableByteChannel ch = Files.newByteChannel( target )) {
//        }
//    }

    @Test
    public void testGetFileName() {
        Path abso = p.readOnlyFileSystem.getPath(p.getLegalPathElement()).toAbsolutePath();

        assertThat( abso.getFileName().getNameCount(), CoreMatchers.is(1) );
        assertThat( abso.getFileName().getFileName(), CoreMatchers.is( abso.getFileName()) );
        assertThat( abso.getFileName(), relative() );

        Path rel = p.readOnlyFileSystem.getPath("");
        assertThat( rel.getFileName().getNameCount(), CoreMatchers.is(1) );
        assertThat( rel.getFileName().getFileName(), CoreMatchers.is( rel.getFileName()) );
        assertThat( rel.getFileName(), relative() );

        Path root = p.readOnlyFileSystem.getPath("").toAbsolutePath().getRoot();

        assertThat( root.getFileName(), CoreMatchers.nullValue());

    }

    @Test
    public void testCopy() throws IOException {
        Path tmp = p.getTmpDir("testCopy");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );

        Files.copy( src, tgt );

        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName("UTF-8") ).get( 0 ) );
    }

    @Test( expected = FileAlreadyExistsException.class )
    public void testCopyAlreadyThere1() throws IOException {
        Path tmp = p.getTmpDir("testCopy");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );
        Files.write( tgt, "duh".getBytes("UTF-8") );

        Files.copy( src, tgt );

        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName("UTF-8") ).get( 0 ) );
    }

    @Test
    public void testCopyAlreadyThereOverwrite() throws IOException {
        Path tmp = p.getTmpDir("testCopy");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );
        Files.write( tgt, "duh".getBytes("UTF-8") );

        Files.copy( src, tgt, StandardCopyOption.REPLACE_EXISTING  );

        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName("UTF-8") ).get( 0 ) );
    }

    @Test
    public void testCopyViaProvider() throws IOException {
        Path tmp = p.getTmpDir("testCopyViaProvider");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );

        tmp.getFileSystem().provider().copy( src, tgt );
        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName("UTF-8") ).get( 0 ) );

    }

//    @Test
//    public void testCopyAlreadyThereOverwriteIdOlder() throws IOException {
//        Path tmp = p.getTmpDir("testCopy");
//        Path src = tmp.resolve( "src" );
//        Path tgt = tmp.resolve( "tgt" );
//        Files.write( src, "Hallo World".getBytes("UTF-8") );
//        Files.write( tgt, "duh".getBytes("UTF-8") );
//
//        Files.copy( src, tgt, StandardCopyOption.REPLACE_EXISTING  );
//
//        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName("UTF-8") ).get( 0 ) );
//    }

    @Test
    public void testGetLastModifiedTime() throws IOException {
        // expect no throw
        Files.readAttributes( p.readOnlyFileSystem.getPath( "" ), BasicFileAttributes.class ).lastModifiedTime();
    }

    @Test
    public void testGetCreationTime() throws IOException {
        // expect no throw
        Files.readAttributes( p.readOnlyFileSystem.getPath( "" ), BasicFileAttributes.class ).creationTime();
    }

    @Test
    public void testGetLastModifiedTimeCorrect() throws IOException {
        Path tmp = p.getTmpDir( "getLastModifiedTimeCorrect" );
        Path tgt = tmp.resolve( "tgt" );

        long first = System.currentTimeMillis();

        Files.write( tgt, "Hallo World".getBytes( "UTF-8" ) );

        long then = System.currentTimeMillis();

        FileTime time = Files.readAttributes( tgt, BasicFileAttributes.class ).lastModifiedTime();

        System.out.println( "" + first + " <= " + time.toMillis() + " <= " + then );
        System.out.println( "" + ImmuDate.valueOf( new Date(first)) + " <= " + ImmuDate.valueOf( new Date(time.toMillis()))  + " <= " + ImmuDate.valueOf( new Date(then )));

        assertTrue( "file time before creation", (first - 1000) <= time.toMillis() );
        assertTrue( "file time after finish", (then + 1000)>= time.toMillis() );
    }


    @Test
    public void testResolveRelative() {
        Path rel = p.readOnlyFileSystem.getPath("");

        Path res  = rel.resolve( p.getLegalPathElement() );

        assertThat( res.isAbsolute(), CoreMatchers.is(false) );
        assertThat( res.toString().endsWith( p.getLegalPathElement()), CoreMatchers.is(true));
    }

    @Test
    public void testSeparator() {
        assertThat( p.readOnlyFileSystem.getSeparator().isEmpty(), CoreMatchers.is(false));

        System.out.println(p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement( 2 ) ));

        assertThat( p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement( 2 )  ).toString().contains( p.readOnlyFileSystem.getSeparator() ), CoreMatchers.is( true ) );
    }

    @Test
    public void testGetPath() {
        assertEquals( p.readOnlyFileSystem.getPath( p.getLegalPathElement() ), p.readOnlyFileSystem.getPath( "", p.getLegalPathElement() ));

        assertEquals( p.readOnlyFileSystem.getPath( p.getLegalPathElement(),
                                                    p.getLegalPathElement( 1 ),
                                                    p.getLegalPathElement(2), p.getLegalPathElement(3) ),
                      p.readOnlyFileSystem.getPath( p.getLegalPathElement() +
                                                        p.readOnlyFileSystem.getSeparator() +
                                                        p.getLegalPathElement(1),
                                                    p.getLegalPathElement(2) +
                                                        p.readOnlyFileSystem.getSeparator() +
                                                        p.getLegalPathElement(3)));
    }


    @Test( expected = NoSuchFileException.class )
    public void testWriteFileWithoutExistingParent() throws IOException {
        Path tmp = p.getTmpDir( "testWriteFileWithoutExistingParent" );

        Files.write( tmp.resolve( "not-there" ).resolve( "duda.txt" ), "hhh".getBytes( "UTF-8" ) );

    }

    @Test
    public void testRWBytes() throws IOException {
        byte[] in = new byte[20];
        for ( int i = 0; i < 20; i++ ) {
            in[i] = (byte) (i -5);
        }

        Path tmp = p.getTmpDir( "RWBytes" );
        Path target = tmp.resolve( p.getLegalPathElement() );

        Files.write( target, in );

        byte[] out = Files.readAllBytes( target );

        assertArrayEquals( in,out );
    }

    @Test
    public void testNewFileIsInDirStream() throws IOException {
        Path dir = p.getTmpDir("testNewFileIsInDirStream");
        Path file = dir.resolve( p.getLegalPathElement() );

        Files.write( file, "haaa".getBytes("UTF-8") );

        boolean found = false;
        try( DirectoryStream<Path> kids = Files.newDirectoryStream( dir )) {
            for( Path kid : kids ) {
                if ( kid.equals( file )) {
                    found = true;
                    break;
                }
            }
        }

        assertTrue( "new dir not in dirstream of parent", found );

    }

    @Test
    public void testNewDirIsInDirStream() throws IOException {
        Path parent = p.getTmpDir("testNewDirIsInDirStream");
        Path dir = parent.resolve( p.getLegalPathElement() );
        Files.createDirectory( dir );


        boolean found = false;
        try( DirectoryStream<Path> kids = Files.newDirectoryStream( parent )) {
            for( Path kid : kids ) {
                if ( kid.equals( dir )) {
                    found = true;
                    break;
                }
            }
        }

        assertTrue( "new file not in dirstream of parent", found );

    }


    @Test
    public void testRWBytes2() throws IOException {
        byte[] in = new byte[20000];
        for ( int i = 0; i < 20000; i++ ) {
            in[i] = (byte) (i);
        }

        Path target = p.getTmpDir("RWBytes2").resolve( p.getLegalPathElement() );

        Files.write( target, in );

        byte[] out = Files.readAllBytes( target );

        assertArrayEquals( in,out );
    }

    @Test
    public void testRWBytesLarge() throws IOException {
        byte[] in = new byte[200000];
        for ( int i = 0; i < 200000; i++ ) {
            in[i] = (byte) (i);
        }

        Path target = p.getTmpDir("RWBytesLarge").resolve( p.getLegalPathElement() );

        Files.write( target, in );

        byte[] out = Files.readAllBytes( target );

        assertArrayEquals( in,out );
    }

    @Test
    public void testRWBytesHugh() throws IOException {
        byte[] in = new byte[5000000];
        for ( int i = 0; i < 5000000; i++ ) {
            in[i] = (byte) (i);
        }

        Path target = p.getTmpDir("RWBytesHugh").resolve( p.getLegalPathElement() );

        Files.write( target, in );

        byte[] out = Files.readAllBytes( target );

        assertArrayEquals( in,out );
    }


    @Test
    public void testReadChunks() throws IOException {
        byte[] in = new byte[10000];
        for ( int i = 0; i < 10000; i++ ) {
            in[i] = (byte) (i);
        }

        Path target = p.getTmpDir("testReadChunks").resolve( p.getLegalPathElement() );

        Files.write( target, in );

        byte[] out = new byte[20000];
        int sum = 0;
        try ( SeekableByteChannel readChannel = Files.newByteChannel( target, StandardOpenOption.READ )) {

            while( true ) {
                ByteBuffer bb = ByteBuffer.wrap( out, sum, 8009 );
                int count = readChannel.read( bb );
                if ( count < 0 ) {
                    break;
                }

                sum += count;

                assertTrue( sum < 12000 );
            }
        }


        assertThat( sum, is(10000) );
        assertArrayEquals( in, Arrays.copyOfRange(out, 0, sum ));
    }

    @Test( expected = ClosedChannelException.class )
    public void testReadFromClosedChannel() throws IOException {
        byte[] in = new byte[20];
        for ( int i = 0; i < 20; i++ ) {
            in[i] = (byte) (i -5);
        }
        Path target = p.getTmpDir("readClosed").resolve( p.getLegalPathElement() );
        Files.write( target, in );

        try ( SeekableByteChannel read =  Files.newByteChannel( target )) {
            read.close();
            assertThat( read.isOpen(), CoreMatchers.is(false));
            read.read( ByteBuffer.allocate(30) ); // should throw
        }
    }

    @Test
    public void testSize() throws IOException {

        int size = 20000;
        byte[] in = new byte[size];
        for ( int i = 0; i < size; i++ ) {
            in[i] = (byte) (i);
        }

        Path tmp = p.getTmpDir( "testSize" );
        Path target = tmp.resolve( p.getLegalPathElement() );

        Files.write( target, in );

        assertEquals( size, Files.readAttributes( target, BasicFileAttributes.class ).size() );
    }

    @Test
    public void testSizeOfDir() throws IOException {
        // the behaviour of the size of a dir is unspecified (e.g. whether it changes with new kids)
        // but it should not throw

        Files.size( p.readOnlyFileSystem.getPath( "" ) );
    }


    @Test
    public void testCreateDirectory() throws IOException {
        Path dir = p.getTmpDir("testCreateDirectory").resolve( p.getLegalPathElement() );
        Files.createDirectory( dir );
        assertThat( dir, exists() );
    }

    @Test( expected = FileAlreadyExistsException.class )
    public void testCreateDirectoryTwice() throws IOException {
        Path dir = p.getTmpDir("createDirTwice").resolve( p.getLegalPathElement() );
        Files.createDirectory( dir );
        Files.createDirectory( dir );
    }

    @Test( expected = NoSuchFileException.class )
    public void testCreateDirectoryFail() throws IOException {
        Files.createDirectory( p.getNonExistingPath().resolve( p.getLegalPathElement() ));
    }

    // bug in java Path
    @Ignore
    @Test( expected = FileAlreadyExistsException.class )
    public void testCreateDirectoryRoot() throws IOException {
        Path dir = p.readOnlyFileSystem.getPath( "" ).getRoot();
        Files.createDirectory( dir );
    }

    @Test
    public void testCreateDirSetsModifiedDateOfParent() throws IOException, InterruptedException {

        Path tmp = p.getTmpDir("testCreateDirSetsModifiedDateOfParent");

        FileTime created = Files.getLastModifiedTime( tmp );

        Thread.sleep( 2000 );

        Files.createDirectory( tmp.resolve( p.getLegalPathElement() ) );
        FileTime modified = Files.getLastModifiedTime( tmp );

        assertTrue( "created after modified", created.compareTo( modified ) < 0 );
    }

    @Test
    public void testModifiedDateDoesNotChangeModifiedDateOfParent() throws IOException, InterruptedException {

        Path tmp = p.getTmpDir("testModifiedDateDoesNotChangeModifiedDateOfParent");
        Files.createDirectory( tmp.resolve( p.getLegalPathElement() ) );
        FileTime created = Files.getLastModifiedTime( tmp );

        Thread.sleep( 2000 );

        Files.createDirectory( tmp.resolve( p.getLegalPathElement() ).resolve( p.getLegalPathElement( 1 )));
        FileTime modified = Files.getLastModifiedTime( tmp );

        assertEquals( created, modified );
    }

    @Test
    public void testCreateFileSetsModifiedDateOfParent() throws IOException, InterruptedException {

        Path tmp = p.getTmpDir("testCreateFileSetsModifiedDateOfParent");

        FileTime created = Files.getLastModifiedTime( tmp );

        Thread.sleep( 2000 );

        Files.write( tmp.resolve( "foo" ), "hh".getBytes() );
        FileTime modified = Files.getLastModifiedTime( tmp );

        assertTrue( "created after modified", created.compareTo( modified ) < 0 );
    }

    @Test
    public void testModifyFileNotSetsModifiedDateOfParent() throws IOException, InterruptedException {

        Path tmp = p.getTmpDir("testCreateFileSetsModifiedDateOfParent");
        Files.write( tmp.resolve( "foo" ), "hh".getBytes() );

        FileTime created = Files.getLastModifiedTime( tmp );

        Thread.sleep( 2000 );

        FileTime modified = Files.getLastModifiedTime( tmp );
        Files.write( tmp.resolve( "foo" ), "duh".getBytes() );

        assertEquals( created, modified  );
    }

    @Test
    public void testDeleteDirChangesParentTime() throws IOException, InterruptedException {
        Path tmp = p.getTmpDir("testDeleteDirChangesParentTime");
        final Path dir = tmp.resolve( p.getLegalPathElement() );
        Files.createDirectory( dir );
        FileTime created = Files.getLastModifiedTime( tmp );

        Thread.sleep( 2000 );

        Files.delete( dir );
        FileTime modified = Files.getLastModifiedTime( tmp );

        assertTrue( "delete does not modify time", created.compareTo( modified ) < 0 );
    }

    @Test
    public void testDeleteFileChangesParentTime() throws IOException, InterruptedException {
        Path tmp = p.getTmpDir("testDeleteDirChangesParentTime");
        final Path file = tmp.resolve( p.getLegalPathElement() );
        Files.write( file, "Hallo duh".getBytes( "UTF-8" ) );
        FileTime created = Files.getLastModifiedTime( tmp );

        Thread.sleep( 2000 );

        Files.delete( file );
        FileTime modified = Files.getLastModifiedTime( tmp );

        assertTrue( "delete does not modify time", created.compareTo( modified ) < 0 );
    }

    @Test
    public void testDeleteDirRemovesItFromParentsKids() throws IOException, InterruptedException {
        Path tmp = p.getTmpDir("testDeleteDirRemovesItFromParentsKids");
        final Path dir = tmp.resolve( p.getLegalPathElement() );
        Files.createDirectory( dir );
        Files.delete( dir );

        try ( DirectoryStream<Path> kids = Files.newDirectoryStream( tmp ) ) {
            assertFalse( "delete dir does not remove it from parent stream", Forall.forall( kids ).contains( dir ));
        }
    }


    @Test
    public void testDeleteFileRemovesItFromParentsKids() throws IOException, InterruptedException {
        Path tmp = p.getTmpDir("testDeleteFileRemovesItFromParentsKids");
        final Path file = tmp.resolve( p.getLegalPathElement() );
        Files.write( file, "Hallo duh".getBytes( "UTF-8" ) );
        Files.delete( file );
        try ( DirectoryStream<Path> kids = Files.newDirectoryStream( tmp ) ) {
            assertFalse( "delete dir does not remove it from parent stream", Forall.forall( kids ).contains( file ));
        }
    }

    @Test
    public void testCreateRelativeDirectory() throws IOException {
        Path abs = p.getTmpDir("createRelativeDirectory").resolve( p.getLegalPathElement() );
        Path rel = abs.getFileSystem().getPath( "" ).toAbsolutePath().relativize( abs );

        Files.createDirectory( rel );
        assertThat( rel, exists() );
    }



    @Test
    public void testResolveAbsolute() {
        Path abs = p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).toAbsolutePath();
        Path base = p.readOnlyFileSystem.getPath( p.getLegalPathElement(2) ).toAbsolutePath();

        assertEquals( abs, base.resolve( abs ) );
    }

    @Test
    public void testResolve3() {
        Path abs = p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).toAbsolutePath();

        assertEquals( abs, abs.resolve( p.readOnlyFileSystem.getPath( "" ) ) );
    }


    @Test
    public void testRelativize() {
        Path shrt = p.readOnlyFileSystem.getPath( p.getLegalPathElement() );
        Path lng = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) );


        assertEquals( lng, shrt.resolve( shrt.relativize( lng ) ) );
    }

    @Test
    public void testRelativizeAbsolute() {
        Path root = p.readOnlyFileSystem.getPath( p.readOnlyFileSystem.getSeparator());
        Path lng = p.readOnlyFileSystem.getPath( p.readOnlyFileSystem.getSeparator(), p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) );
        Path lngRel = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) );

        assertEquals( lngRel, root.relativize( lng ) );

    }


    @Test( expected = IllegalArgumentException.class )
    public void testRelativizeMixed() {
        Path shrt = p.readOnlyFileSystem.getPath( p.getLegalPathElement() );
        Path lng = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) ).toAbsolutePath();


        shrt.relativize( lng );
    }

    @Test( expected = IllegalArgumentException.class )
    public void testRelativizeMixed2() {
        Path shrt = p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).toAbsolutePath();
        Path lng = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) );


        shrt.relativize( lng );
    }


    @Test
    public void testGetParent() {
        Path rel = p.readOnlyFileSystem.getPath( p.getLegalPathElement() );
        assertThat( rel.getParent(), IsNull.nullValue() );

        Path abs = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(2) ).toAbsolutePath();
        assertEquals( abs, abs.resolve( p.getLegalPathElement() ).getParent() );

        assertThat( abs.getRoot().getParent(), IsNull.nullValue());

    }

    @Test
    public void testWildPaths() {
        Path abs = p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).toAbsolutePath();

        assertEquals( abs.getParent(), abs.resolve( ".." ).normalize() );
        assertEquals( abs.getParent(), abs.resolve( "../aa/../." ).normalize() );

        Path rel = p.readOnlyFileSystem.getPath( p.getLegalPathElement() );

        assertEquals( "", rel.resolve( ".." ).normalize().toString() );

    }

    @Test
    public void testPathIterator() {
        Path path = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement( 1 ), p.getLegalPathElement(2) );

        int i = 0;
        for ( Path kid : path ) {
            assertEquals( p.readOnlyFileSystem.getPath( p.getLegalPathElement( i ) ), kid );
            i++;
        }
    }


    @Test( expected = java.nio.file.DirectoryNotEmptyException.class )
    public void testDeleteNonEmptyDirectory() throws IOException {

        Files.delete( p.getNonEmptyDir("deleteNonEmpty"));
    }

    @Test
    public void testDeleteEmptyDir() throws IOException {
        Path dir = p.getTmpDir("testDeleteEmptyDir").resolve( p.getLegalPathElement() );
        Files.createDirectory( dir );
        assertThat( dir, exists() );
        Files.delete( dir );
        assertThat( dir, not( exists() ) );
    }


    // another parent of root problem
    @Ignore
    @Test
    public void testDeleteRoot() throws IOException {

        Files.delete( p.readOnlyFileSystem.getPath( "" ).getRoot() );
    }

    @Test
    public void testGetName() {
        Path path = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1) );

        assertEquals( p.readOnlyFileSystem.getPath( p.getLegalPathElement() ), path.getName( 0 ));
        assertEquals( p.readOnlyFileSystem.getPath( p.getLegalPathElement(1) ), path.getName( 1 ));
    }

    @Test( expected = IllegalArgumentException.class )
    public void testGetNameNegative() {
        Path path = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1) );
        path.getName( -1 );
    }

    @Test( expected = IllegalArgumentException.class )
    public void testGetNameLarge() {
        Path path = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1) );
        path.getName( 5 );
    }

    @Test
    public void testGetNameDefault() {
        Path dflt = p.readOnlyFileSystem.getPath( "" );
        assertEquals( dflt, dflt.getName( 0 ) );

    }

    @Test
    public void testEndsWith() {
        Path lng = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) );
        Path shrt = p.readOnlyFileSystem.getPath( p.getLegalPathElement(1), p.getLegalPathElement(2) );
        Path start = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1) );

        assertThat( lng.endsWith( shrt ), CoreMatchers.is(true) );
        assertThat( lng.endsWith( start ), CoreMatchers.is(false) );
    }

    @Test
    public void testEndsWithString() {
        Path lng = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) );
        String shrt = p.getLegalPathElement(1) + p.readOnlyFileSystem.getSeparator() + p.getLegalPathElement(2);
        String start = p.getLegalPathElement() + p.readOnlyFileSystem.getSeparator() + p.getLegalPathElement(1);

        assertThat( lng.endsWith( shrt ), CoreMatchers.is(true) );
        assertThat( lng.endsWith( start ), CoreMatchers.is(false) );
    }



    @Ignore
    @Test
    public void testFSClosable() throws IOException {
        p.readOnlyFileSystem.close();
    }

    @Test
    public void testRootIsSymbolicLinkNot() {
        assertFalse( "root is a symbolic link", Files.isSymbolicLink( p.readOnlyFileSystem.getPath( p.readOnlyFileSystem.getSeparator() )));
    }

    @Test
    public void testReadFromExausted() throws IOException {
        Path tmp = p.getTmpDir( "testReadFormExausted" ).resolve( p.getLegalPathElement() );

        Files.write( tmp, "hallo".getBytes( "UTF-8" ) );
        SeekableByteChannel channel = tmp.getFileSystem().provider().newByteChannel( tmp, Collections.singleton( READ ));

        channel.read( ByteBuffer.allocate( 500 ) );
        ByteBuffer bb = ByteBuffer.allocate( 500 );
        int ret = channel.read( bb );

        assertEquals( -1, ret );
        assertEquals( 0, bb.position() );
    }

    // todo other filesystem
//    @Test
//    public void testEndsWithAbs() {
//        Path lng = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1), p.getLegalPathElement(2) ).toAbsolutePath();
//        Path shrt = p.readOnlyFileSystem.getPath( p.getLegalPathElement(1), p.getLegalPathElement(2) ).toAbsolutePath();
////        Path start = p.readOnlyFileSystem.getPath( p.getLegalPathElement(), p.getLegalPathElement(1) );
//
//        assertThat( lng.endsWith( shrt ), CoreMatchers.is(true) );
//  //      assertThat( lng.endsWith( start ), CoreMatchers.is(false) );
//
//    }


    @Test
    public void testGetScheme() {
        p.readOnlyFileSystem.provider().getScheme();
    }

    @Test( expected = IllegalArgumentException.class )
    public void testWrongUri() {
        p.readOnlyFileSystem.provider().getFileSystem(
                URI.create( p.readOnlyFileSystem.provider().getScheme()+ "N:/" ));
    }

    @Test( expected = IllegalArgumentException.class )
    public void testWrongUriAtNew() throws IOException {
        p.readOnlyFileSystem.provider().newFileSystem(
                URI.create( p.readOnlyFileSystem.provider().getScheme()+ "N:/" ),
                Collections.EMPTY_MAP );
    }

    @Test( expected = FileSystemNotFoundException.class )
    public void testGetUnknownFileSystem() {
        assumeTrue( !p.getCapabilities().oneFileSystemOnly() );

        p.readOnlyFileSystem.provider().getFileSystem( p.getUriForUnknownFS() );
    }

    @Test
    public void testNewFileSystem() throws IOException {
        assumeTrue( !p.getCapabilities().oneFileSystemOnly() );

        FileSystem fs  = p.readOnlyFileSystem.provider().newFileSystem( p.getUriForNewFS(), p.getEnvForNewFS() );

        assertThat( fs, CoreMatchers.notNullValue() );
    }

    @Test( expected = FileSystemAlreadyExistsException.class )
    public void testNewFileSystemAgain() throws IOException {
        final URI uri = p.readOnlyFileSystem.getPath( "" ).toAbsolutePath().toUri();
        p.readOnlyFileSystem.provider().newFileSystem( uri, p.getEnvForNewFS() );
    }

    @Test
    public void testGetExistingFileSystem() throws IOException {
        if ( p.getUriForExistingFS() != null ) {
            FileSystem fs  = p.readOnlyFileSystem.provider().getFileSystem( p.getUriForExistingFS() );

            assertThat( fs, notNullValue() );
        }
    }

    @Test
    public void testPathToUri() {
        Path path = p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).toAbsolutePath();

        URI uri = path.toUri();

        assertThat( uri, notNullValue() );

        Path back = p.readOnlyFileSystem.provider().getPath( uri );

        assertEquals( path, back );
    }

    @Test
    public void testUriToPath() throws Exception {
        Path path = p.readOnlyFileSystem.getPath( p.getLegalPathElement() ).toAbsolutePath();
        URI uri = path.toUri();

        Path p2 = Paths.get( uri );

        assertThat( p2, is( path ));


    }


    @Test
    public void testMove() throws IOException {
        Path tmp = p.getTmpDir("testMove");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );

        Files.move( src, tgt );

        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName("UTF-8") ).get( 0 ) );
        assertThat( src, not( exists()) );
    }

    @Test
    public void testMoveAlreadyThere1() throws IOException {
        Path tmp = p.getTmpDir("testCopy");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );
        Files.write( tgt, "duh".getBytes("UTF-8") );

        try {
            Files.move( src, tgt );
            fail( "expected FileAlreadyExistsException" );
        } catch( FileAlreadyExistsException exp ) {
        }

        assertThat( src, exists() );
    }

    @Test
    public void testMoveAlreadyThereOverwrite() throws IOException {
        Path tmp = p.getTmpDir("testCopy");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );
        Files.write( tgt, "duh".getBytes("UTF-8") );

        Files.move( src, tgt, StandardCopyOption.REPLACE_EXISTING  );

        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName("UTF-8") ).get( 0 ) );
        assertThat( src, not( exists()) );
    }


    @Test
    public void testMoveViaProvider() throws IOException {
        Path tmp = p.getTmpDir("testCopyViaProvider");
        Path src = tmp.resolve( "src" );
        Path tgt = tmp.resolve( "tgt" );
        Files.write( src, "Hallo World".getBytes("UTF-8") );

        tmp.getFileSystem().provider().move( src, tgt );
        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName( "UTF-8" ) ).get( 0 ) );
        assertThat( src, not( exists() ) );
    }

    @Test
    public void testIsSameFile() throws IOException {
        Path tmp = p.getTmpDir("testIsSameFile");
        Path path1 = tmp.resolve( "path1" );

        Path path2 = tmp.resolve( "path1" );

        assertTrue( "should be same", tmp.getFileSystem().provider().isSameFile( path1, path2 ) );
    }

    @Test
    public void testIsSameFileNot() throws IOException {
        Path tmp = p.getTmpDir("testIsSameFileNot");
        Path path1 = tmp.resolve( "path1" );
        Path path2 = tmp.resolve( "path2" );

        Files.write( path1, "Hallo World".getBytes("UTF-8") );
        Files.write( path2, "Hallo World".getBytes("UTF-8") );


        assertFalse( "should not be same", tmp.getFileSystem().provider().isSameFile( path1, path2 ) );
    }

    @Test( expected = NoSuchFileException.class )
    public void testIsSameFileNotExists() throws IOException {
        Path tmp = p.getTmpDir("testIsSameFileNotExists");
        Path path1 = tmp.resolve( "path1" );
        Path path2 = tmp.resolve( "path2" );

        tmp.getFileSystem().provider().isSameFile( path1, path2 );
    }

    @Test( expected = NoSuchFileException.class )
    public void testWriteNonExistent() throws IOException {

        Path notthere = p.getTmpDir( "testWriteNonExistent" ).resolve( "not-exists" );

        try ( SeekableByteChannel ch = p.readOnlyFileSystem.provider().newByteChannel( notthere, Collections.singleton( StandardOpenOption.WRITE ) )) {}
    }

    @Test
    public void testWriteExists() throws IOException {

        Path there = p.getTmpDir( "testWriteExists" ).resolve( "not-exists" );
        Files.write( there, "huh".getBytes( "UTF-8" ) );

        try ( SeekableByteChannel ch = p.readOnlyFileSystem.provider().newByteChannel( there, Collections.singleton( StandardOpenOption.WRITE ) )) {}

        assertEquals( 3, Files.size( there ) );
    }

    @Test
    public void testWriteAndCreateNonExistent() throws IOException {

        Path notthere = p.getTmpDir( "testWriteAndCreateNonExistent" ).resolve( "not-exists" );

        Set<StandardOpenOption> options = new HashSet<>();
        options.add( StandardOpenOption.WRITE );
        options.add( StandardOpenOption.CREATE );

        try ( SeekableByteChannel ch = p.readOnlyFileSystem.provider().newByteChannel( notthere, options )) {}

        assertThat( notthere, exists() );
    }

    @Test
    public void testWriteAndCreateExistent() throws IOException {

        Path there = p.getTmpDir( "testWriteAndCreateNonExistent" ).resolve( "not-exists" );
        Files.write( there, "huh".getBytes( "UTF-8" ) );

        Set<StandardOpenOption> options = new HashSet<>();
        options.add( StandardOpenOption.WRITE );
        options.add( StandardOpenOption.CREATE );

        try ( SeekableByteChannel ch = p.readOnlyFileSystem.provider().newByteChannel( there, options )) {}

        assertThat( there, exists() );
    }

    @Test
    public void testWriteAndCreateNewNonExistent() throws IOException {

        Path notthere = p.getTmpDir( "testWriteAndCreateNewNonExistent" ).resolve( "not-exists" );

        Set<StandardOpenOption> options = new HashSet<>();
        options.add( StandardOpenOption.WRITE );
        options.add( StandardOpenOption.CREATE_NEW );

        try ( SeekableByteChannel ch = p.readOnlyFileSystem.provider().newByteChannel( notthere, options )) {}

        assertThat( notthere, exists() );
    }

    @Test( expected = FileAlreadyExistsException.class )
    public void testWriteOnlyNew() throws IOException {

        Path there = p.getTmpDir( "testWriteOnlyNew" ).resolve( "not-exists" );
        Files.write( there, "huh".getBytes( "UTF-8" ) );

        Set<StandardOpenOption> options = new HashSet<>();
        options.add( StandardOpenOption.WRITE );
        options.add( StandardOpenOption.CREATE_NEW );

        try ( SeekableByteChannel ch = p.readOnlyFileSystem.provider().newByteChannel( there, options )) {}
    }

    @Test
    public void testOverwriteTruncateExisting() throws IOException {

        Path there = p.getTmpDir( "testWriteOnlyNew" ).resolve( "not-exists" );
        Files.write( there, "huh".getBytes( "UTF-8" ) );

        Set<StandardOpenOption> options = new HashSet<>();
        options.add( StandardOpenOption.WRITE );
        options.add( StandardOpenOption.TRUNCATE_EXISTING );

        try ( SeekableByteChannel ch = p.readOnlyFileSystem.provider().newByteChannel( there, options )) {}

        assertThat( there, exists() );
        assertEquals( 0, Files.size( there ) );
    }


    @Test
    public void testClosedFSisClosed() throws Exception {

        assumeTrue( p.getCapabilities().canBeClosed());

        FileSystem fs = p.getTmpDir( "" ).getFileSystem();
        fs.close();

        assertFalse( "should be closed", fs.isOpen() );

    }

    @Test( expected = ClosedFileSystemException.class )
    public void testOpenDirectoryStreamFromClosedFS() throws Exception {
        assumeTrue( p.getCapabilities().canBeClosed());

        p.readOnlyFileSystem.close();

        try ( DirectoryStream<Path> ch = Files.newDirectoryStream( p.readOnlyFileSystem.getPath( "" ) )) {
        }
    }

    @Test( expected = ProviderMismatchException.class )
    public void testCallNewDirectoryStreamWithForeignPath() throws Exception {

        assumeTrue( !p.readOnlyFileSystem.equals( FileSystems.getDefault() ));

        try ( DirectoryStream<Path> ch = p.getProvider().newDirectoryStream( FileSystems.getDefault().getPath( "" ), new DirectoryStream.Filter<Path>() {
            @Override
            public boolean accept( Path entry ) throws IOException {
                todo();
                return false;  //To change body of implemented methods use File | Settings | File Templates.
            }
        })) {}


    }


// TODO 2 different FS
//    @Test
//    public void testMoveViaProviderDifferentFileSystems() throws IOException {
//        Path tmp = p.getTmpDir("testMoveViaProviderDifferentFileSystems");
//        Path tmp2 = p.getTmpDir("testMoveViaProviderDifferentFileSystems2");
//        Path src = tmp.resolve( "src" );
//        Path tgt = tmp2.resolve( "tgt" );
//        Files.write( src, "Hallo World".getBytes("UTF-8") );
//
//        tmp.getFileSystem().provider().move( src, tgt );
//        assertEquals( "Hallo World", Files.readAllLines( tgt, Charset.forName( "UTF-8" ) ).get( 0 ) );
//        assertThat( src, not( exists() ) );
//
//    }

//    @Test
//    public void testHm() throws Exception {
//
//        URI uri = URI.create( "file:///Users/stephan" );
//
////        FileSystems.getFileSystem( uri );
//
//        FileSystemProvider prov = null;
//
//        String scheme = uri.getScheme();
//        for (FileSystemProvider provider: FileSystemProvider.installedProviders()) {
//            if (scheme.equalsIgnoreCase(provider.getScheme())) {
//                prov = provider;
//            }
//        }
//
//        prov.getPath( uri );
//
//
//
//    }


    @Test
    public void testName() throws Exception {

        //define a folder root
        Path myDir = p.getTmpDir("");

        try {
            WatchService watcher = myDir.getFileSystem().newWatchService();
            myDir.register(watcher, StandardWatchEventKinds.ENTRY_CREATE,
                    StandardWatchEventKinds.ENTRY_DELETE, StandardWatchEventKinds.ENTRY_MODIFY);

            WatchKey watckKey = watcher.take();

            List<WatchEvent<?>> events = watckKey.pollEvents();
            for (WatchEvent event : events) {
                if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE) {
                    System.out.println("Created: " + event.context().toString());
                }
                if (event.kind() == StandardWatchEventKinds.ENTRY_DELETE) {
                    System.out.println("Delete: " + event.context().toString());
                }
                if (event.kind() == StandardWatchEventKinds.ENTRY_MODIFY) {
                    System.out.println("Modify: " + event.context().toString());
                }
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }
}
